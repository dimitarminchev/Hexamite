# -*- coding: utf-8 -*-
"""
Created on Wed Mar 18 08:08:29 2015
@author: Gisli Gissurarson
"""
import sys, os, shutil
path = os.getcwd()
shutil.copy2(path+'/system.txt', path+'/compiler/bin/system.txt')   
os.chdir(path+'/compiler/bin')
os.system('hx7loadRun.py')
