
extern void pinSerialOut(char x);
extern void usartOutD1(char x);
extern char * pinSerialIn(char xx[]);
extern char * getFlashData(char xx[],char nn);


void setup(void)
{
	PORTC_DIR=0xC0;
	OSC_XOSCCTRL=0xCB;
	OSC_PLLCTRL=0xC2;
	OSC_CTRL=0x18;
	while(!(OSC_STATUS&0x8));
	while(!(OSC_STATUS&0x10));
	CPU_CCP=0xD8;
	CLK_CTRL=0x4;
	CPU_CCP=0xD8;
	PORTC_PIN2CTRL=0x18;
	PORTC_PIN3CTRL=0x18;
	PORTCFG_VPCTRLB=0x32;
	NVM_CTRLB=0x8;
/*	
	USARTD1_BAUDCTRLA=0x6B;
	USARTD1_BAUDCTRLB=0xB0;
	USARTD1_CTRLC=0x3;
	USARTD1_CTRLA=0x0;
	USARTD1_CTRLB=0x8;
*/
    ADCA_CTRLA=0x19;
    ADCA_PRESCALER=1;
    DACB_CTRLC=0x8;
    DACB_CTRLA=5;
    DACB_CH0DATA=0x0675;
}

void pinOut(char *format, ...)
{
    char buffer[80];
    va_list aptr;
    int ret,i;

    va_start(aptr, format);
    ret = vsprintf(buffer, format, aptr);
    va_end(aptr);
	for(i=0;i<ret;i++)
			{
				pinSerialOut(buffer[i]);
				//usartOutD1(buffer[i]); Not a good idea
			}	
}
