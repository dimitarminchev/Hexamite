#include	<avr/io.h>
#define     board_LED_high  	        PORTD_OUT=PORTD_OUT|0x10
#define     board_LED_low 	            PORTD_OUT=PORTD_OUT&0xE7

#define     set_a0_as_Output           	PORTA_DIR=PORTA_DIR|0x1
#define     set_a0_as_Input           	PORTA_DIR=PORTA_DIR&0xFE
#define     a0_is_high                 	PORTA_IN&0x1
#define     set_a0_high        			PORTA_OUT=PORTA_OUT|0x1
#define     set_a0_low  	           	PORTA_OUT=PORTA_OUT&0xFE

#define     set_a1_as_Output           	PORTA_DIR=PORTA_DIR|0x2
#define     set_a1_as_Input           	PORTA_DIR=PORTA_DIR&0xFD
#define     a1_is_high                 	PORTA_IN&0x2
#define     set_a1_high        			PORTA_OUT=PORTA_OUT|0x2
#define     set_a1_low  	           	PORTA_OUT=PORTA_OUT&0xFD

#define     set_a2_as_Output           	PORTA_DIR=PORTA_DIR|0x4
#define     set_a2_as_Input           	PORTA_DIR=PORTA_DIR&0xFB
#define     a2_is_high                 	PORTA_IN&0x4
#define     set_a2_high        			PORTA_OUT=PORTA_OUT|0x4
#define     set_a2_low  	           	PORTA_OUT=PORTA_OUT&0xFB

#define     set_a3_as_Output           	PORTA_DIR=PORTA_DIR|0x8
#define     set_a3_as_Input           	PORTA_DIR=PORTA_DIR&0xF7
#define     a3_is_high                 	PORTA_IN&0x8
#define     set_a3_high        			PORTA_OUT=PORTA_OUT|0x8
#define     set_a3_low  	           	PORTA_OUT=PORTA_OUT&0xF7

#define     set_a4_as_Output           	PORTA_DIR=PORTA_DIR|0x10
#define     set_a4_as_Input           	PORTA_DIR=PORTA_DIR&0xEF
#define     a4_is_high                 	PORTA_IN&0x10
#define     set_a4_high        			PORTA_OUT=PORTA_OUT|0x10
#define     set_a4_low  	           	PORTA_OUT=PORTA_OUT&0xEF

#define     set_a5_as_Output           	PORTA_DIR=PORTA_DIR|0x20
#define     set_a5_as_Input           	PORTA_DIR=PORTA_DIR&0xDF
#define     a5_is_high                 	PORTA_IN&0x20
#define     set_a5_high        			PORTA_OUT=PORTA_OUT|0x20
#define     set_a5_low  	           	PORTA_OUT=PORTA_OUT&0xDF

#define     set_a6_as_Output           	PORTA_DIR=PORTA_DIR|0x40
#define     set_a6_as_Input           	PORTA_DIR=PORTA_DIR&0xBF
#define     a6_is_high                 	PORTA_IN&0x40
#define     set_a6_high        			PORTA_OUT=PORTA_OUT|0x40
#define     set_a6_low  	           	PORTA_OUT=PORTA_OUT&0xBF

#define     set_a7_as_Output           	PORTA_DIR=PORTA_DIR|0x80
#define     set_a7_as_Input           	PORTA_DIR=PORTA_DIR&0x7F
#define     a7_is_high                 	PORTA_IN&0x80
#define     set_a7_high        			PORTA_OUT=PORTA_OUT|0x80
#define     set_a7_low  	           	PORTA_OUT=PORTA_OUT&0x7F

#define     set_b0_as_Output           	PORTB_DIR=PORTB_DIR|0x1
#define     set_b0_as_Input           	PORTB_DIR=PORTB_DIR&0xFE
#define     b0_is_high                 	PORTB_IN&0x1
#define     set_b0_high        			PORTB_OUT=PORTB_OUT|0x1
#define     set_b0_low  	           	PORTB_OUT=PORTB_OUT&0xFE

#define     set_b1_as_Output           	PORTB_DIR=PORTB_DIR|0x2
#define     set_b1_as_Input           	PORTB_DIR=PORTB_DIR&0xFD
#define     b1_is_high                 	PORTB_IN&0x2
#define     set_b1_high        			PORTB_OUT=PORTB_OUT|0x2
#define     set_b1_low  	           	PORTB_OUT=PORTB_OUT&0xFD

#define     set_b2_as_Output           	PORTB_DIR=PORTB_DIR|0x4
#define     set_b2_as_Input           	PORTB_DIR=PORTB_DIR&0xFB
#define     b2_is_high                 	PORTB_IN&0x4
#define     set_b2_high        			PORTB_OUT=PORTB_OUT|0x4
#define     set_b2_low  	           	PORTB_OUT=PORTB_OUT&0xFB

#define     set_b3_as_Output           	PORTB_DIR=PORTB_DIR|0x8
#define     set_b3_as_Input           	PORTB_DIR=PORTB_DIR&0xF7
#define     b3_is_high                 	PORTB_IN&0x8
#define     set_b3_high        			PORTB_OUT=PORTB_OUT|0x8
#define     set_b3_low  	           	PORTB_OUT=PORTB_OUT&0xF7

#define     set_c2_as_Output           	PORTC_DIR=PORTC_DIR|0x4
#define     set_c2_as_Input           	PORTC_DIR=PORTC_DIR&0xFB
#define     c2_is_high                 	PORTC_IN&0x4
#define     set_c2_high        			PORTC_OUT=PORTC_OUT|0x4
#define     set_c2_low  	           	PORTC_OUT=PORTC_OUT&0xFB

#define     set_c3_as_Output           	PORTC_DIR=PORTC_DIR|0x8
#define     set_c3_as_Input           	PORTC_DIR=PORTC_DIR&0xF7
#define     c3_is_high                 	PORTC_IN&0x8
#define     set_c3_high        			PORTC_OUT=PORTC_OUT|0x8
#define     set_c3_low  	           	PORTC_OUT=PORTC_OUT&0xF7

#define     set_c4_as_Output           	PORTC_DIR=PORTC_DIR|0x10
#define     set_c4_as_Input           	PORTC_DIR=PORTC_DIR&0xEF
#define     c4_is_high                 	PORTC_IN&0x10
#define     set_c4_high        			PORTC_OUT=PORTC_OUT|0x10
#define     set_c4_low  	           	PORTC_OUT=PORTC_OUT&0xEF

#define     set_c5_as_Output           	PORTC_DIR=PORTC_DIR|0x20
#define     set_c5_as_Input           	PORTC_DIR=PORTC_DIR&0xDF
#define     c5_is_high                 	PORTC_IN&0x20
#define     set_c5_high        			PORTC_OUT=PORTC_OUT|0x20
#define     set_c5_low  	           	PORTC_OUT=PORTC_OUT&0xDF

#define     set_c6_as_Output           	PORTC_DIR=PORTC_DIR|0x40
#define     set_c6_as_Input           	PORTC_DIR=PORTC_DIR&0xBF
#define     c6_is_high                 	PORTC_IN&0x40
#define     set_c6_high        			PORTC_OUT=PORTC_OUT|0x40
#define     set_c6_low  	           	PORTC_OUT=PORTC_OUT&0xBF

#define     set_c7_as_Output           	PORTC_DIR=PORTC_DIR|0x80
#define     set_c7_as_Input           	PORTC_DIR=PORTC_DIR&0x7F
#define     c7_is_high                 	PORTC_IN&0x80
#define     set_c7_high        			PORTC_OUT=PORTC_OUT|0x80
#define     set_c7_low  	           	PORTC_OUT=PORTC_OUT&0x7F

#define     set_d0_as_Output           	PORTD_DIR=PORTD_DIR|0x1
#define     set_d0_as_Input           	PORTD_DIR=PORTD_DIR&0xFE
#define     d0_is_high                 	PORTD_IN&0x1
#define     set_d0_high        			PORTD_OUT=PORTD_OUT|0x1
#define     set_d0_low  	           	PORTD_OUT=PORTD_OUT&0xFE

#define     set_d1_as_Output           	PORTD_DIR=PORTD_DIR|0x2
#define     set_d1_as_Input           	PORTD_DIR=PORTD_DIR&0xFD
#define     d1_is_high                 	PORTD_IN&0x2
#define     set_d1_high        			PORTD_OUT=PORTD_OUT|0x2
#define     set_d1_low  	           	PORTD_OUT=PORTD_OUT&0xFD

#define     set_d2_as_Output           	PORTD_DIR=PORTD_DIR|0x4
#define     set_d2_as_Input           	PORTD_DIR=PORTD_DIR&0xFB
#define     d2_is_high                 	PORTD_IN&0x4
#define     set_d2_high        			PORTD_OUT=PORTD_OUT|0x4
#define     set_d2_low  	           	PORTD_OUT=PORTD_OUT&0xFB

#define     set_d3_as_Output           	PORTD_DIR=PORTD_DIR|0x8
#define     set_d3_as_Input           	PORTD_DIR=PORTD_DIR&0xF7
#define     d3_is_high                 	PORTD_IN&0x8
#define     set_d3_high        			PORTD_OUT=PORTD_OUT|0x8
#define     set_d3_low  	           	PORTD_OUT=PORTD_OUT&0xF7

#define     set_d4_as_Output           	PORTD_DIR=PORTD_DIR|0x10
#define     set_d4_as_Input           	PORTD_DIR=PORTD_DIR&0xEF
#define     d4_is_high                 	PORTD_IN&0x10
#define     set_d4_high        			PORTD_OUT=PORTD_OUT|0x10
#define     set_d4_low  	           	PORTD_OUT=PORTD_OUT&0xEF

#define     set_d5_as_Output           	PORTD_DIR=PORTD_DIR|0x20
#define     set_d5_as_Input           	PORTD_DIR=PORTD_DIR&0xDF
#define     d5_is_high                 	PORTD_IN&0x20
#define     set_d5_high        			PORTD_OUT=PORTD_OUT|0x20
#define     set_d5_low  	           	PORTD_OUT=PORTD_OUT&0xDF

#define     set_d6_as_Output           	PORTD_DIR=PORTD_DIR|0x40
#define     set_d6_as_Input           	PORTD_DIR=PORTD_DIR&0xBF
#define     d6_is_high                 	PORTD_IN&0x40
#define     set_d6_high        			PORTD_OUT=PORTD_OUT|0x40
#define     set_d6_low  	           	PORTD_OUT=PORTD_OUT&0xBF

#define     set_d7_as_Output           	PORTD_DIR=PORTD_DIR|0x80
#define     set_d7_as_Input           	PORTD_DIR=PORTD_DIR&0x7F
#define     d7_is_high                 	PORTD_IN&0x80
#define     set_d7_high        			PORTD_OUT=PORTD_OUT|0x80
#define     set_d7_low  	           	PORTD_OUT=PORTD_OUT&0x7F

#define     set_e0_as_Output           	PORTE_DIR=PORTE_DIR|0x1
#define     set_e0_as_Input           	PORTE_DIR=PORTE_DIR&0xFE
#define     e0_is_high                 	PORTE_IN&0x1
#define     set_e0_high        			PORTE_OUT=PORTE_OUT|0x1
#define     set_e0_low  	           	PORTE_OUT=PORTE_OUT&0xFE

#define     set_e1_as_Output           	PORTE_DIR=PORTE_DIR|0x2
#define     set_e1_as_Input           	PORTE_DIR=PORTE_DIR&0xFD
#define     e1_is_high                 	PORTE_IN&0x2
#define     set_e1_high        			PORTE_OUT=PORTE_OUT|0x2
#define     set_e1_low  	           	PORTE_OUT=PORTE_OUT&0xFD

#define     set_e2_as_Output           	PORTE_DIR=PORTE_DIR|0x4
#define     set_e2_as_Input           	PORTE_DIR=PORTE_DIR&0xFB
#define     e2_is_high                 	PORTE_IN&0x4
#define     set_e2_high        			PORTE_OUT=PORTE_OUT|0x4
#define     set_e2_low  	           	PORTE_OUT=PORTE_OUT&0xFB

#define     set_e3_as_Output           	PORTE_DIR=PORTE_DIR|0x8
#define     set_e3_as_Input           	PORTE_DIR=PORTE_DIR&0xF7
#define     e3_is_high                 	PORTE_IN&0x8
#define     set_e3_high        			PORTE_OUT=PORTE_OUT|0x8
#define     set_e3_low  	           	PORTE_OUT=PORTE_OUT&0xF7



void set_base_32mhz(void)
{
	PORTC_DIR=0xC0;
	OSC_XOSCCTRL=0xCB;
	OSC_PLLCTRL=0xC2;
	OSC_CTRL=0x18;
	while(!(OSC_STATUS&0x8));
	while(!(OSC_STATUS&0x10));
	CPU_CCP=0xD8;
	CLK_CTRL=0x4;
	CPU_CCP=0xD8;    
	PORTCFG_VPCTRLA=0x14;
	PORTCFG_VPCTRLB=0x32;
	PORTB_PIN2CTRL=0x19;
	PORTB_PIN3CTRL=0x19;
	PORTC_PIN2CTRL=0x19;
	PORTC_PIN3CTRL=0x19;
	PORTC_PIN4CTRL=0x19;
	PORTC_PIN5CTRL=0x19;
	PORTC_PIN6CTRL=0x19;
	PORTC_PIN7CTRL=0x19;
	PORTD_PIN0CTRL=0x19;
	PORTD_PIN1CTRL=0x19;
	PORTD_PIN2CTRL=0x19;
	PORTD_PIN3CTRL=0x19;
	PORTD_PIN4CTRL=0x19;
	PORTD_PIN5CTRL=0x19;
	PORTD_PIN6CTRL=0x19;
	PORTD_PIN7CTRL=0x19;
	PORTA_DIR=0;
	PORTB_DIR=0;
	PORTC_DIR=0;
	PORTD_DIR=0;
	PORTE_DIR=0;
	PORTD_DIR=PORTD_DIR|0x10;
}
void delay32uS(unsigned int xx)
{
	TCD0_CTRLB=TCD0_CNT=0;
  	TCD0_PER=xx;  
	TCD0_CTRLA=7;     				//timer ticks every 0.000032 seconds so delay = 6250*0.000032=0.2S
    while(!(TCD0_INTFLAGS&0x1)) ;	//loop here until time out every 0.2Seconds	
    TCD0_INTFLAGS=0x1;
}