#include	<stdarg.h>
#include	<avr/io.h>

extern void pinSerialOut(char x);
extern void usartOutD1(char x);
extern int pinSerialIn(char xx[]);
extern char * getFlashData(char dataBuffer[],char flashAddress,char flashBank);

void pinOut(char *format, ...)
{
    char buffer[80];
    va_list aptr;
    int ret,i;
    PORTD_OUT=PORTD_IN|0x80;
    PORTD_DIR=PORTD_DIR|0x80;
    va_start(aptr, format);
    ret = vsprintf(buffer, format, aptr);
    va_end(aptr);
	for(i=0;i<ret;i++)
    {
		pinSerialOut(buffer[i]);
		// usartOutD1(buffer[i]); // Not a good idea
    }	
    PORTD_DIR=PORTD_DIR&0x7F;
}
