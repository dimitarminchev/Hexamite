#include	<avr/io.h>
#define		gControl1		0x20
#define		aControl1		0x20
#define		genControl1		0x0C
#define		genControl2		0x06
#define		Accelerator		0x28
#define		Gyroscope		0x18
#define		Temperature		0x15
#define		fifoStatus		0xAF
#define		fifoClear		0x00
#define		fifoControl		0x20

#define		CTRL_REG1_G		0x10
#define		CTRL_REG6_XL	0x20
#define		CTRL_REG8		0x22
#define		CTRL_REG9		0x23
#define		FIFO_CTRL		0x2E

extern void open_SPI_IMU(void);
extern void close_SPI_IMU(void);
extern void put_SPI_byte(char address,char byte);
extern char get_SPI_byte(char address);
extern char * get_SPI_data(int xdata[],char numberOfBytes,char xlocation);
