/*
 * HX7 Robot Project
 * ---
 * Created: 7.12.2016 08:00:00 AM
 * Author: Dimitar Minchev
 *
 */ 
 
// Include Needed Libraries
#include	<avr/io.h>
#include	<pinDialog.h>
#include    <sys_clock.h>

// Define Some Stuff
#define     motorStandby          PORTC_OUTCLR=0x20;
#define     motorActive           PORTC_DIRSET=0xFC;PORTD_DIRSET=0x1;PORTC_OUTSET=0x20;
// Motor A
#define     motorSpeed_a          TCC0_CCCBUF
#define     motorCW_a             PORTC_OUTSET=0x10;PORTC_OUTCLR=0x40; // C4=1, C6=0
#define     motorCCW_a            PORTC_OUTCLR=0x10;PORTC_OUTSET=0x40; // C4=0, C6=1
#define     motorShortBreak_a     PORTC_OUTSET=0x10;PORTC_OUTSET=0x40; // C4=1, C6=1
#define     motorStop_a           PORTC_OUTCLR=0x10;PORTC_OUTCLR=0x40; // C4=0, C6=0
// Motor B
#define     motorSpeed_b          TCC0_CCDBUF
#define     motorCCW_b            PORTC_OUTSET=0x80;PORTD_OUTCLR=0x1; // C7=1, D0=0
#define     motorCW_b             PORTC_OUTCLR=0x80;PORTD_OUTSET=0x1; // C7=0, D0=1
#define     motorShortBreak_b     PORTC_OUTSET=0x80;PORTD_OUTSET=0x1; // C7=1, D0=1
#define     motorStop_b           PORTC_OUTCLR=0x80;PORTD_OUTCLR=0x1; // C7=0, D0=0
// Speed
#define     RES_32MHZ             1
#define     RES_16MHZ             2
#define     RES_8MHZ              3
#define     RES_4MHZ              4
#define     RES_500KHZ            5
#define     RES_125KHZ            6
#define     RES_31250HZ           7
#define     SELECT_0              1
#define     SELECT_1              2
#define     SELECT_2              4
#define     SELECT_3              8
#define     SELECT_4              16
#define     SELECT_5              32
#define     SELECT_6              64
#define     SELECT_7              128

// Set PWM on pin C2 and C3
void pwm_c2_c3(int period_range,char time_resolution,char active_pin)
{
    // active.bit0 = 1, c4 = enabled, active.bit1 = 1, c5 = enabled
    if(active_pin&0x4) set_c2_as_Output;
    if(active_pin&0x8) set_c3_as_Output;
    TCC0_PERBUF = period_range;
    TCC0_CTRLB = (active_pin<<4)|3;
    TCC0_CTRLA = time_resolution;
}

// Main Function
int main(void)
{
	// set processor clock frequency to 32mhz
	set_base_32mhz(); 

	// Commands
	char cmd[10], id[10];
	getFlashData(id,6,1); 
	
	// Motors
    unsigned Lpwm = 0, Rpwm = 0;
    motorActive;
    pwm_c2_c3(800,RES_16MHZ,SELECT_2+SELECT_3); // 20KHz

	// Forever Loop
	while(1)
	{		
		// device hangs and waits for a string with newline termination
		int len = pinSerialIn(cmd);	
		// pinOut("\n%s Received: %s\n",id,cmd); // echo
		
	    // received command
        int L = cmd[0];  // left
        int R = cmd[1];  // right	
        // pinOut("\nL: %i\tR: %i\n",L,R); // echo
		
        // Control Left Motor
        if(L >= 97)
        {
           Lpwm = (L - 97)*32;
           motorCW_a; // forward    
        }
        else if(L <= 89)
        {
            Lpwm = (L - 65)*32;        
            motorCCW_a; // reverse    
        }
		else 
		{
			Lpwm = 0; 
			motorShortBreak_a; // break
			motorStop_a; // stop    
		}
      
        // Conrol Right Motor
        if(R >= 97)
        {
           Rpwm = (R - 97)*32;
           motorCW_b; // forward     
        }
        else if(R <= 89)
        {
           Rpwm = (R - 65)*32;
           motorCCW_b; // reverse    
        }
		else // stop 
		{
			Rpwm = 0;
			motorShortBreak_b; // break
			motorStop_b; // stop  
		}
		
	    // Set Motor Sppeed by PWM Duty Cycle
        motorSpeed_a = Lpwm;
        motorSpeed_b = Rpwm;
	}
}